﻿var LAT_DebugTest = (function () {
    return {
        Test_Function: function () {
            //debugger;

        	Xrm.Utility.alertDialog("Hello");
        }
    }
}());