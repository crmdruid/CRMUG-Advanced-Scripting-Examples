﻿var LAT_DebugTest = (function () {
    return {
        Test_Function: function () {
            //debugger;

            alert("Hello");
        }
    }
}());